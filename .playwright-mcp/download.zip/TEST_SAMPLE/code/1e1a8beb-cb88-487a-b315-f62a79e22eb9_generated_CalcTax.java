package com.migration.generated;

import java.math.BigDecimal;
import java.math.RoundingMode;

import lombok.Data;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.*;

/**
 * 移行元: CALC-TAX
 * 生成者: CodeMigrationAgent (Legacy-to-Agent™)
 */
@Service
@Data
public class CalcTax {

    // === Fields (WORKING-STORAGE) ===
    private BigDecimal income;
    private BigDecimal taxRate;
    private BigDecimal taxAmt;

    // === Methods (PROCEDURE DIVISION) ===
    public void executeProcedureDivision() {
        System.out.println("Executing Procedure Division");
    }
    public void executeProgram() {
        this.executeProcedureDivision();
    }

    public static void main(String[] args) {
        CalcTax instance = new CalcTax();
        instance.executeProgram();
    }
}